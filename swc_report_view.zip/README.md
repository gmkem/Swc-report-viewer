# SWC Report App (Flutter)

โปรเจกต์นี้คือส่วน Frontend ของแอป "ระบบตรวจสอบรายงาน SWC"

## วิธีใช้งาน (สำคัญ)
เนื่องจาก Flutter ต้องใช้ไฟล์ระบบ Android
กรุณาทำขั้นตอนนี้บนคอมพิวเตอร์:

1. flutter create swc_report_app
2. คัดลอกโฟลเดอร์เหล่านี้ไปทับของใหม่
   - lib/
   - assets/
   - pubspec.yaml
3. flutter pub get
4. flutter build apk --release

จากนั้นจะได้ไฟล์ APK ใช้งานจริง

## GitHub Actions
มี workflow สำหรับ build APK อัตโนมัติแล้ว (flutter-build.yml)
